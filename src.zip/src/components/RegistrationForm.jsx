import { useState } from 'react';
import { supabase } from '../services/supabaseClient';

export const RegistrationForm = ({ onSuccess, restaurantId, referidoPor }) => {
  const [formData, setFormData] = useState({ nombre: '', telefono: '', fechaNacimiento: '' });
  const [loading,  setLoading]  = useState(false);
  const [mostrarTerminos, setMostrarTerminos] = useState(false);

  const hoy = new Date();
  const fechaMaxima = hoy.toISOString().split('T')[0];
  const hace90     = new Date(); hace90.setFullYear(hoy.getFullYear() - 90);
  const fechaMinima = hace90.toISOString().split('T')[0];

  const handleChange = (e) => {
    const { id, value } = e.target;
    const key = id === 'whatsapp' ? 'telefono' : id === 'nacimiento' ? 'fechaNacimiento' : id;
    setFormData(prev => ({ ...prev, [key]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (loading) return;
    if (!formData.nombre.trim() || !formData.telefono.trim() || !formData.fechaNacimiento) {
      alert('Por favor, completa todos los campos.');
      return;
    }
    setLoading(true);
    try {
      const { data: existente, error: errorBusqueda } = await supabase
        .from('clientes').select('id, nombre, puntos')
        .eq('telefono', formData.telefono.trim())
        .eq('restaurante_id', restaurantId)
        .maybeSingle();

      if (errorBusqueda) throw errorBusqueda;

      if (existente) {
        onSuccess?.(existente.id, existente.nombre, existente.puntos);
        setLoading(false);
        return;
      }

      const { data, error: errorInsert } = await supabase
        .from('clientes').insert([{
          nombre:          formData.nombre.trim(),
          telefono:        formData.telefono.trim(),
          fecha_nacimiento: formData.fechaNacimiento,
          puntos:          2,
          origen:          'Registro Web',
          restaurante_id:  restaurantId,
          referidopor:     referidoPor || 'Directo (QR local)',
          fecha_registro:  new Date().toISOString(),
        }]).select().single();

      if (errorInsert) throw errorInsert;
      onSuccess?.(data.id, formData.nombre.trim(), 2);
    } catch (error) {
      console.error('Error en registro:', error);
      if (error?.code === '23505') {
        alert(
          'Este teléfono ya está registrado en otro restaurante y la base de ' +
          'datos aún no permite registros independientes por sede. ' +
          'Contacta al administrador para actualizar la restricción UNIQUE en la tabla "clientes".'
        );
      } else {
        alert('Hubo un problema al procesar los datos. Intenta de nuevo.');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <form onSubmit={handleSubmit} style={styles.card}>
        {/* Header */}
        <div style={styles.header}>
          <h2 style={styles.title}>Crea tu perfil</h2>
          <p style={styles.subtitle}>Regístrate hoy y gana tus primeros 2 puntos</p>
        </div>

        {/* Fields */}
        <div style={styles.field}>
          <label style={styles.label} htmlFor="nombre">Nombre completo</label>
          <input id="nombre" type="text" required placeholder="Ej: Juan Pérez"
            style={styles.input} value={formData.nombre} onChange={handleChange} />
        </div>

        <div style={styles.field}>
          <label style={styles.label} htmlFor="whatsapp">Teléfono / WhatsApp</label>
          <input id="whatsapp" type="tel" required pattern="[0-9]{10}"
            placeholder="Ej: 3206587850" style={styles.input}
            value={formData.telefono} onChange={handleChange} />
        </div>

        <div style={{ ...styles.field, marginBottom: '1.25rem' }}>
          <label style={styles.label} htmlFor="nacimiento">Fecha de nacimiento</label>
          <input id="nacimiento" type="date" required min={fechaMinima} max={fechaMaxima}
            style={styles.input} value={formData.fechaNacimiento} onChange={handleChange} />
        </div>

        {/* Submit */}
        <button type="submit" disabled={loading} style={{
          ...styles.btnJoin,
          opacity: loading ? 0.75 : 1,
          cursor:  loading ? 'not-allowed' : 'pointer',
        }}>
          {loading ? (
            <span style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
              <span style={styles.spinner} /> Procesando…
            </span>
          ) : 'Unirme al club →'}
        </button>

        {/* Benefits strip */}
        <div style={styles.benefitsRow}>
          {[
            { num: '+2', label: 'puntos hoy' },
            { num: '20', label: 'para premio' },
            { num: '30', label: 'días validez' },
          ].map(({ num, label }) => (
            <div key={label} style={styles.benefitPill}>
              <span style={styles.benefitNum}>{num}</span>
              <span style={styles.benefitLabel}>{label}</span>
            </div>
          ))}
        </div>

        {/* Terms link */}
        <p style={styles.termsLink} onClick={() => setMostrarTerminos(true)}>
          * Al unirte aceptas los Términos y Condiciones
        </p>

        <p style={styles.secureNote}>🔒 Tus datos están protegidos</p>
      </form>

      {/* Modal de términos */}
      {mostrarTerminos && (
        <div style={styles.overlay}>
          <div style={styles.modal}>
            <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '1.1rem', marginBottom: '1rem', color: 'var(--text-h)' }}>
              Términos y Condiciones
            </h3>
            <div style={{ fontSize: '0.85rem', color: 'var(--text)', lineHeight: 1.7 }}>
              <p><strong>1. Puntos:</strong> Recibirás 2 puntos por cada visita confirmada mediante PIN del personal.</p>
              <p style={{ marginTop: 10 }}><strong>2. Premios:</strong> Al completar 20 puntos se activa un cupón. Preséntalo al mesero.</p>
              <p style={{ marginTop: 10 }}><strong>3. Vencimiento:</strong> Los puntos vencen a los 30 días sin nueva visita.</p>
              <p style={{ marginTop: 10 }}><strong>4. Datos:</strong> Autorizas el uso de tus datos solo para este programa de fidelización.</p>
            </div>
            <button type="button" onClick={() => setMostrarTerminos(false)} style={styles.btnJoin}>
              Entendido
            </button>
          </div>
        </div>
      )}
    </>
  );
};

/* ── Inline styles (evita dependencia de CSS externo para este componente) ── */
const styles = {
  card: {
    background: 'var(--bg-card)',
    padding: '1.75rem',
    borderRadius: 'var(--r-xl)',
    border: '1px solid var(--border)',
    boxShadow: 'var(--shadow-card)',
    width: '100%',
  },
  header: { marginBottom: '1.25rem' },
  title: {
    fontFamily: 'var(--font-display)',
    fontSize: '1.3rem',
    fontWeight: 700,
    color: 'var(--text-h)',
    marginBottom: 4,
  },
  subtitle: { fontSize: '0.85rem', color: 'var(--text)', opacity: 0.8 },
  field:  { marginBottom: '1rem' },
  label: {
    display: 'block',
    fontSize: '10px',
    fontWeight: 600,
    letterSpacing: '0.08em',
    textTransform: 'uppercase',
    color: 'var(--text)',
    opacity: 0.7,
    marginBottom: 5,
  },
  input: {
    width: '100%',
    padding: '11px 14px',
    fontSize: 16, /* evita zoom en iPhone */
    fontFamily: 'var(--font-body)',
    fontWeight: 400,
    background: 'var(--bg-subtle)',
    border: '1.5px solid var(--border)',
    borderRadius: 'var(--r-md)',
    color: 'var(--text-h)',
    outline: 'none',
    transition: 'border-color 0.2s, box-shadow 0.2s',
  },
  btnJoin: {
    display: 'block',
    width: '100%',
    padding: '13px',
    marginTop: '4px',
    background: 'var(--coral)',
    color: 'white',
    border: 'none',
    borderRadius: 'var(--r-md)',
    fontFamily: 'var(--font-display)',
    fontWeight: 700,
    fontSize: '0.9rem',
    letterSpacing: '0.05em',
    textTransform: 'uppercase',
    cursor: 'pointer',
    boxShadow: 'var(--shadow-btn)',
    transition: 'background 0.2s, transform 0.1s',
  },
  spinner: {
    display: 'inline-block',
    width: 16, height: 16,
    border: '2px solid rgba(255,255,255,0.35)',
    borderTopColor: 'white',
    borderRadius: '50%',
    animation: 'spin 0.7s linear infinite',
  },
  benefitsRow: { display: 'flex', gap: 6, marginTop: 14 },
  benefitPill: {
    flex: 1,
    background: 'var(--bg-subtle)',
    borderRadius: 'var(--r-sm)',
    padding: '8px 4px',
    textAlign: 'center',
    display: 'flex',
    flexDirection: 'column',
    gap: 2,
  },
  benefitNum: {
    fontFamily: 'var(--font-display)',
    fontWeight: 800,
    fontSize: '1.15rem',
    color: 'var(--coral)',
    lineHeight: 1,
  },
  benefitLabel: { fontSize: '10px', color: 'var(--text)', fontWeight: 500 },
  termsLink: {
    marginTop: 12,
    fontSize: '0.7rem',
    color: 'var(--coral)',
    textDecoration: 'underline',
    cursor: 'pointer',
    textAlign: 'center',
    fontStyle: 'italic',
  },
  secureNote: {
    marginTop: 8,
    fontSize: '0.7rem',
    textAlign: 'center',
    opacity: 0.4,
    color: 'var(--text)',
  },
  overlay: {
    position: 'fixed', inset: 0,
    background: 'rgba(0,0,0,0.45)',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    zIndex: 1000, padding: '1.5rem',
  },
  modal: {
    background: 'var(--bg-card)',
    borderRadius: 'var(--r-xl)',
    padding: '1.5rem',
    width: '100%',
    maxWidth: 420,
    maxHeight: '80vh',
    overflowY: 'auto',
    boxShadow: '0 20px 60px rgba(0,0,0,0.2)',
    display: 'flex',
    flexDirection: 'column',
    gap: '1rem',
  },
};
