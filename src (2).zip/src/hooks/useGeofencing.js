/**
 * useGeofencing.js — LoyalPass (migrado a @capgo/background-geolocation)
 */

import { useState, useEffect, useRef, useCallback } from 'react';
import { Capacitor, registerPlugin } from '@capacitor/core';
import { LocalNotifications } from '@capacitor/local-notifications';
import { supabase } from '../services/supabaseClient';

const BackgroundGeolocation = registerPlugin('BackgroundGeolocation');

const CANAL_ID_GEOFENCE = 'geofence-alerts';

async function asegurarCanalNotificacionNativo() {
  if (Capacitor.getPlatform() !== 'android') return;
  try {
    await LocalNotifications.createChannel({
      id: CANAL_ID_GEOFENCE,
      name: 'Alertas de cercanía',
      description: 'Avisos cuando estás cerca de un restaurante afiliado',
      importance: 5, // IMPORTANCE_HIGH → heads-up + sonido
      visibility: 1,
    });
  } catch (err) {
    console.warn('[useGeofencing] Error creando canal de notificación:', err.message);
  }
}

function distanciaMetros(lat1, lon1, lat2, lon2) {
  const R = 6371000;
  const rLat1 = (lat1 * Math.PI) / 180;
  const rLat2 = (lat2 * Math.PI) / 180;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(rLat1) * Math.cos(rLat2) * Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

// Mapea la lista de restaurantes (formato del provider) al formato exacto
// que espera addGeofences() de @capgo/background-geolocation.
function mapearAGeofences(restaurantes) {
  return restaurantes
    .filter(
      (r) =>
        r.restaurante_id &&
        !isNaN(parseFloat(r.latitud)) &&
        !isNaN(parseFloat(r.longitud))
    )
    .map((r) => ({
      id: String(r.restaurante_id),
      latitude: parseFloat(r.latitud),
      longitude: parseFloat(r.longitud),
      radius: parseInt(r.radio_aviso, 10) || 200,
      notifyOnEntry: true,
      notifyOnExit: true,
    }));
}

export function useGeofencing(restaurantes) {
  const [estado, setEstado] = useState('idle');
  const [dentroDeRango, setDentroDeRango] = useState([]);
  const [proximos, setProximos] = useState([]);
  const [notifInApp, setNotifInApp] = useState([]);

  const restaurantesRef = useRef(restaurantes);
  const watcherIdRef = useRef(null);
  const transitionListenerRef = useRef(null);

  useEffect(() => {
    restaurantesRef.current = restaurantes;
  }, [restaurantes]);

  const buscarRestaurantePorId = useCallback(
    (id) => restaurantesRef.current.find((r) => String(r.restaurante_id) === String(id)),
    []
  );

  const mostrarNotifNativa = useCallback(async (resto) => {
    try {
      await LocalNotifications.schedule({
        notifications: [
          {
            id: Date.now() % 2147483647,
            title: `¡Estás cerca de ${resto.nombre}!`,
            body:
              resto.mensaje_promo ||
              `Confirma tu llegada y gana +${resto.puntos_llegada ?? 2} puntos`,
            channelId: CANAL_ID_GEOFENCE,
            smallIcon: 'ic_stat_icon',
            extra: {
              url: `${window.location.origin}/?r=${resto.restaurante_id}`,
              restauranteId: resto.restaurante_id,
            },
          },
        ],
      });
    } catch (err) {
      console.warn('[useGeofencing] Error mostrando notificación nativa:', err.message);
    }
  }, []);

  // Callback del evento nativo 'geofenceTransition'. Forma esperada del
  // evento: { identifier, action: 'ENTER' | 'EXIT' } — ajustar si la versión
  // instalada del plugin usa otros nombres de campo (revisar tipos del paquete).
  const manejarTransicion = useCallback(
    (evento) => {
      const { identifier, action } = evento || {};
      if (!identifier) return;
      const resto = buscarRestaurantePorId(identifier);
      if (!resto) return;

      if (action === 'ENTER') {
        setDentroDeRango((prev) => (prev.includes(identifier) ? prev : [...prev, identifier]));
        mostrarNotifNativa(resto);
        setNotifInApp((prev) => [
          ...prev,
          {
            id: `${identifier}-${Date.now()}`,
            restauranteId: identifier,
            nombre: resto.nombre,
            mensaje:
              resto.mensaje_promo || `Confirma tu llegada y gana +${resto.puntos_llegada ?? 2} puntos`,
            timestamp: Date.now(),
          },
        ]);
        supabase
          .from('metricas_proximidad')
          .insert({ restaurante_id: identifier, origen: 'nativo_capgo', exito: true })
          .then(() => {})
          .catch(() => {});
      }

      if (action === 'EXIT') {
        setDentroDeRango((prev) => prev.filter((id) => id !== identifier));
      }
    },
    [buscarRestaurantePorId, mostrarNotifNativa]
  );

  // Actualiza `proximos` (todos los restaurantes ordenados por distancia,
  // no solo los que están dentro del radio) en cada tick del watcher.
  const actualizarProximos = useCallback((uLat, uLon) => {
    const lista = restaurantesRef.current
      .map((r) => ({
        ...r,
        distanciaMetros: Math.round(
          distanciaMetros(uLat, uLon, parseFloat(r.latitud), parseFloat(r.longitud))
        ),
      }))
      .sort((a, b) => a.distanciaMetros - b.distanciaMetros);
    setProximos(lista);
  }, []);

  const iniciarRastreo = useCallback(async () => {
    if (restaurantesRef.current.length === 0) return;
    setEstado('solicitando_permiso');

    try {
      const permisoNotif = await LocalNotifications.requestPermissions();
      if (permisoNotif.display !== 'granted') {
        console.warn('[useGeofencing] Permiso de notificaciones no concedido');
      }
      await asegurarCanalNotificacionNativo();

      const geofences = mapearAGeofences(restaurantesRef.current);
      if (geofences.length === 0) {
        setEstado('idle');
        return;
      }

      transitionListenerRef.current = await BackgroundGeolocation.addListener(
        'geofenceTransition',
        manejarTransicion
      );

      await BackgroundGeolocation.addGeofences({ geofences });

      const watcherId = await BackgroundGeolocation.addWatcher(
        {
          backgroundTitle: 'LoyalPass está activo',
          backgroundMessage: 'Te avisaremos cuando estés cerca de tus restaurantes favoritos.',
          requestPermissions: true,
          stale: false,
          distanceFilter: 15,
        },
        (location, error) => {
          if (error) {
            console.warn('[useGeofencing] Error BackgroundGeolocation:', error.message);
            if (error.code === 'NOT_AUTHORIZED') setEstado('sin_permiso');
            return;
          }
          if (location) actualizarProximos(location.latitude, location.longitude);
        }
      );

      watcherIdRef.current = watcherId;
      setEstado('rastreando');
      console.log('[useGeofencing] Rastreo + geocercas (capgo) iniciados ✅');
    } catch (err) {
      console.warn('[useGeofencing] Error inicializando rastreo:', err.message);
      setEstado('sin_permiso');
    }
  }, [manejarTransicion, actualizarProximos]);

  const detenerRastreo = useCallback(async () => {
    try {
      if (watcherIdRef.current) {
        await BackgroundGeolocation.removeWatcher({ id: watcherIdRef.current });
        watcherIdRef.current = null;
      }
      if (transitionListenerRef.current) {
        await transitionListenerRef.current.remove();
        transitionListenerRef.current = null;
      }
      const ids = mapearAGeofences(restaurantesRef.current).map((g) => g.id);
      if (ids.length > 0) {
        await BackgroundGeolocation.removeGeofences({ ids });
      }
    } catch (err) {
      console.warn('[useGeofencing] Error deteniendo rastreo:', err.message);
    }
    setEstado('idle');
    setDentroDeRango([]);
    setProximos([]);
  }, []);

  const limpiarNotifInApp = useCallback(() => setNotifInApp([]), []);

  useEffect(() => {
    if (restaurantes.length === 0) return;
    iniciarRastreo();
    return () => {
      detenerRastreo();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [restaurantes.length]);

  return { dentroDeRango, estado, proximos, notifInApp, limpiarNotifInApp };
}
